/**
 * CompVerify Portal - Simple All-in-One Server
 * Double-click START-PORTAL.bat (Windows) or START-PORTAL.command (Mac)
 */

require('dotenv').config({ path: __dirname + '/.env' });
const express  = require('express');
const session  = require('express-session');
const bcrypt   = require('bcryptjs');
const multer   = require('multer');
const axios    = require('axios');
const Database = require('better-sqlite3');
const fs       = require('fs');
const path     = require('path');
const cron     = require('node-cron');

const app  = express();
const PORT = 3000;

// ── Database ──────────────────────────────────────────────────────────────────
if (!fs.existsSync('./data')) fs.mkdirSync('./data');
const db = new Database('./data/compverify.db');
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT
  );
  CREATE TABLE IF NOT EXISTS policies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_number TEXT NOT NULL,
    insured_name  TEXT,
    carrier       TEXT,
    state         TEXT NOT NULL DEFAULT 'NY',
    expiry_date   TEXT,
    status        TEXT DEFAULT 'pending',
    last_checked  TEXT,
    check_count   INTEGER DEFAULT 0,
    notes         TEXT,
    created_at    TEXT DEFAULT (datetime('now')),
    updated_at    TEXT DEFAULT (datetime('now'))
  );
  CREATE TABLE IF NOT EXISTS check_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    policy_id  INTEGER,
    checked_at TEXT DEFAULT (datetime('now')),
    status     TEXT,
    message    TEXT
  );
`);

// Seed admin user if not exists
const adminExists = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@yourcompany.com');
if (!adminExists) {
  db.prepare('INSERT INTO users(email,password,name) VALUES(?,?,?)').run(
    'admin@yourcompany.com',
    bcrypt.hashSync('Admin1234!', 10),
    'Admin User'
  );
}

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: 'compverify-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 8 * 60 * 60 * 1000 }
}));

const upload = multer({ dest: './uploads/', limits: { fileSize: 20 * 1024 * 1024 } });
if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');

function auth(req, res, next) {
  if (req.session.userId) return next();
  res.status(401).json({ error: 'Not logged in' });
}

// ── WCB VERIFICATION ──────────────────────────────────────────────────────────
/**
 * HOW THE VERIFICATION WORKS:
 *
 * NY WCB: Checks https://www.wcb.ny.gov/content/main/Employers/VerifyCoverage.jsp
 * NJ WC:  Checks https://www.njcrib.com/Certificate/Search
 *
 * Both boards have PUBLIC lookup pages. This code submits the policy
 * number to those pages and reads back whether it's active or not.
 *
 * For high volume (500+/day), you can request official API access:
 *   NY: https://www.wcb.ny.gov  → contact their EDI team
 *   NJ: https://www.njcrib.com  → Contact Us → request bulk access
 */
async function checkPolicyStatus(policyNumber, state, carrier = '') {
  try {
    if (state === 'NY') return await checkNYWCB(policyNumber, carrier);
    if (state === 'NJ') return await checkNJWC(policyNumber, carrier);
    return { status: 'error', message: 'Unknown state' };
  } catch (err) {
    return { status: 'error', message: err.message };
  }
}

async function checkNYWCB(policyNumber, carrier) {
  // Submit to NY WCB public coverage verification form
  const formData = new URLSearchParams({
    policyNo:    policyNumber,
    carrierCode: carrier || '',
  });

  const res = await axios.post(
    'https://www.wcb.ny.gov/content/main/Employers/VerifyCoverage.jsp',
    formData.toString(),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'CompVerify/1.0',
      },
      timeout: 15000,
    }
  );

  const html = res.data.toLowerCase();

  // Read the response HTML to determine status
  if (html.includes('coverage is in force') || html.includes('policy is active')) {
    return { status: 'active', message: 'Active — confirmed by NY WCB' };
  } else if (html.includes('coverage has lapsed') || html.includes('expired')) {
    return { status: 'expired', message: 'Expired — confirmed by NY WCB' };
  } else if (html.includes('cancelled')) {
    return { status: 'expired', message: 'Cancelled — confirmed by NY WCB' };
  } else if (html.includes('no record') || html.includes('not found')) {
    return { status: 'not_found', message: 'Not found in NY WCB system' };
  } else {
    return { status: 'unknown', message: 'Could not determine status — check manually at wcb.ny.gov' };
  }
}

async function checkNJWC(policyNumber, carrier) {
  // Submit to NJCRIB public certificate search
  const formData = new URLSearchParams({
    PolicyNumber: policyNumber,
    CarrierName:  carrier || '',
    SearchType:   'PolicyNumber',
  });

  const res = await axios.post(
    'https://www.njcrib.com/Certificate/Search',
    formData.toString(),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'CompVerify/1.0',
      },
      timeout: 15000,
    }
  );

  const html = res.data.toLowerCase();

  if (html.includes('policy is active') || html.includes('in force')) {
    return { status: 'active', message: 'Active — confirmed by NJ CRIB' };
  } else if (html.includes('not in force') || html.includes('expired')) {
    return { status: 'expired', message: 'Expired — confirmed by NJ CRIB' };
  } else if (html.includes('cancelled')) {
    return { status: 'expired', message: 'Cancelled — confirmed by NJ CRIB' };
  } else if (html.includes('no results') || html.includes('not found')) {
    return { status: 'not_found', message: 'Not found in NJ system' };
  } else {
    return { status: 'unknown', message: 'Could not determine — check manually at njcrib.com' };
  }
}

// Extract policy number from uploaded PDF text
function extractPolicyNumber(text) {
  const patterns = [
    /policy\s*(?:no|number|#)[:\s]+([A-Z0-9\-]+)/i,
    /(?:WC|workers.?comp)[:\s\-]*([A-Z0-9\-]{6,20})/i,
    /([A-Z]{2,3}\-\d{4}\-\d{4,8})/,
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return m[1].trim();
  }
  return null;
}

// ── AUTH ROUTES ───────────────────────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }
  req.session.userId = user.id;
  req.session.userName = user.name;
  res.json({ ok: true, name: user.name });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ ok: true });
});

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'Not logged in' });
  res.json({ id: req.session.userId, name: req.session.userName });
});

// ── POLICY ROUTES ─────────────────────────────────────────────────────────────
app.get('/api/policies', auth, (req, res) => {
  const { state, status, q } = req.query;
  let sql = 'SELECT * FROM policies WHERE 1=1';
  const p = [];
  if (state && state !== 'all') { sql += ' AND state=?'; p.push(state); }
  if (status && status !== 'all') { sql += ' AND status=?'; p.push(status); }
  if (q) { sql += ' AND (policy_number LIKE ? OR insured_name LIKE ?)'; p.push(`%${q}%`, `%${q}%`); }
  sql += ' ORDER BY updated_at DESC';
  const policies = db.prepare(sql).all(...p);

  const counts = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) as active,
      SUM(CASE WHEN status IN ('expired','not_found','cancelled') THEN 1 ELSE 0 END) as expired,
      SUM(CASE WHEN status='pending' OR status='unknown' THEN 1 ELSE 0 END) as pending
    FROM policies
  `).get();

  res.json({ policies, counts });
});

// Add policy manually
app.post('/api/policies', auth, (req, res) => {
  const { policy_number, state, carrier, insured_name, expiry_date } = req.body;
  if (!policy_number || !state) return res.status(400).json({ error: 'Policy number and state required' });
  const r = db.prepare(
    'INSERT INTO policies(policy_number,state,carrier,insured_name,expiry_date,status) VALUES(?,?,?,?,?,?)'
  ).run(policy_number.trim(), state, carrier || null, insured_name || null, expiry_date || null, 'pending');
  res.json({ id: r.lastInsertRowid, message: 'Added' });
});

// Verify a single policy NOW
app.post('/api/policies/:id/verify', auth, async (req, res) => {
  const policy = db.prepare('SELECT * FROM policies WHERE id=?').get(Number(req.params.id));
  if (!policy) return res.status(404).json({ error: 'Not found' });

  const result = await checkPolicyStatus(policy.policy_number, policy.state, policy.carrier);

  db.prepare(`
    UPDATE policies SET status=?, notes=?, last_checked=datetime('now'), check_count=check_count+1, updated_at=datetime('now')
    WHERE id=?
  `).run(result.status, result.message, policy.id);

  db.prepare('INSERT INTO check_log(policy_id,status,message) VALUES(?,?,?)').run(policy.id, result.status, result.message);

  res.json({ ...result, policy_number: policy.policy_number });
});

// Delete a policy
app.delete('/api/policies/:id', auth, (req, res) => {
  db.prepare('DELETE FROM policies WHERE id=?').run(Number(req.params.id));
  res.json({ ok: true });
});

// Verify ALL policies
app.post('/api/verify-all', auth, async (req, res) => {
  res.json({ message: 'Verification started for all policies' });
  const all = db.prepare('SELECT * FROM policies').all();
  for (const policy of all) {
    const result = await checkPolicyStatus(policy.policy_number, policy.state, policy.carrier);
    db.prepare(`UPDATE policies SET status=?,notes=?,last_checked=datetime('now'),check_count=check_count+1,updated_at=datetime('now') WHERE id=?`)
      .run(result.status, result.message, policy.id);
    db.prepare('INSERT INTO check_log(policy_id,status,message) VALUES(?,?,?)').run(policy.id, result.status, result.message);
    await new Promise(r => setTimeout(r, 1500)); // 1.5s delay between checks
  }
  console.log('[Verify All] Done');
});

// Upload PDF and extract policy number
app.post('/api/upload', auth, upload.array('files', 50), async (req, res) => {
  const results = [];
  for (const file of req.files || []) {
    try {
      let text = '';
      if (file.mimetype === 'application/pdf') {
        const pdfParse = require('pdf-parse');
        const buf = fs.readFileSync(file.path);
        const data = await pdfParse(buf);
        text = data.text;
      }
      const policyNumber = extractPolicyNumber(text);
      const state = req.body.state || 'NY';
      if (policyNumber) {
        const r = db.prepare(
          'INSERT OR IGNORE INTO policies(policy_number,state,status,notes) VALUES(?,?,?,?)'
        ).run(policyNumber, state, 'pending', 'Extracted from: ' + file.originalname);
        results.push({ file: file.originalname, policy_number: policyNumber, id: r.lastInsertRowid, status: 'added' });
      } else {
        results.push({ file: file.originalname, status: 'no_policy_found', note: 'Could not extract policy number — try entering it manually' });
      }
    } catch (err) {
      results.push({ file: file.originalname, status: 'error', error: err.message });
    }
    fs.unlink(file.path, () => {});
  }
  res.json({ results });
});

// Export CSV
app.get('/api/export', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM policies ORDER BY state,status').all();
  const cols = ['policy_number','insured_name','carrier','state','status','expiry_date','last_checked','notes'];
  const csv  = [cols.join(','), ...rows.map(r => cols.map(c => `"${(r[c]||'').toString().replace(/"/g,'""')}"`).join(','))].join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="policies_${new Date().toISOString().slice(0,10)}.csv"`);
  res.send(csv);
});

// ── DAILY AUTO CHECK (7 AM) ───────────────────────────────────────────────────
cron.schedule('0 7 * * *', async () => {
  console.log('[Daily Check] Starting...');
  const all = db.prepare('SELECT * FROM policies').all();
  for (const policy of all) {
    const result = await checkPolicyStatus(policy.policy_number, policy.state, policy.carrier);
    db.prepare(`UPDATE policies SET status=?,notes=?,last_checked=datetime('now'),check_count=check_count+1,updated_at=datetime('now') WHERE id=?`)
      .run(result.status, result.message, policy.id);
    await new Promise(r => setTimeout(r, 1500));
  }
  console.log('[Daily Check] Complete —', all.length, 'policies checked');
}, { timezone: 'America/New_York' });

// ── FRONTEND ──────────────────────────────────────────────────────────────────
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public/index.html')));

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════════╗');
  console.log('║   CompVerify Portal is running!          ║');
  console.log('║   Open: http://localhost:3000            ║');
  console.log('║   Email:    admin@yourcompany.com        ║');
  console.log('║   Password: Admin1234!                   ║');
  console.log('╚══════════════════════════════════════════╝');
});
